import AppIntents

struct TurnLightOn: AppIntent {
    static var title: LocalizedStringResource = "Turn Light On"
    static var description = IntentDescription("Advertise captured BLE service UUIDs for lamp ON.")
    static var openAppWhenRun: Bool = true

    @MainActor
    func perform() async throws -> some IntentResult {
        try LampController.shared.send(.on)
        return .result()
    }
}

struct TurnLightOff: AppIntent {
    static var title: LocalizedStringResource = "Turn Light Off"
    static var description = IntentDescription("Advertise captured BLE service UUIDs for lamp OFF.")
    static var openAppWhenRun: Bool = true

    @MainActor
    func perform() async throws -> some IntentResult {
        try LampController.shared.send(.off)
        return .result()
    }
}

struct LightShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: TurnLightOn(),
            phrases: ["Turn on the light with \(.applicationName)"],
            shortTitle: "Light On",
            systemImageName: "lightbulb.fill"
        )
        AppShortcut(
            intent: TurnLightOff(),
            phrases: ["Turn off the light with \(.applicationName)"],
            shortTitle: "Light Off",
            systemImageName: "lightbulb.slash.fill"
        )
    }
}
