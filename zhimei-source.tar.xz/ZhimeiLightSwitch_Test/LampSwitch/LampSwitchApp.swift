import SwiftUI

@main
struct LampSwitchApp: App {
    var body: some Scene {
        WindowGroup {
            LampView()
                .onOpenURL { url in
                    guard url.scheme == "zhimei-switch" else { return }
                    let action: LampAction?
                    switch url.host?.lowercased() {
                    case "on": action = .on
                    case "off": action = .off
                    default: action = nil
                    }
                    if let action {
                        do {
                            try LampController.shared.send(action)
                        } catch {
                            LampController.shared.showError(error)
                        }
                    }
                }
        }
    }
}
