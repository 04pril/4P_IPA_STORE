import Foundation
import CoreBluetooth
import Combine

// Two advertising UUID frames transcribed from the user's iPad screen.
// UNLABELLED: Neither has been proven to mean light ON or light OFF.
enum CapturedSample: String, CaseIterable, Identifiable {
    case sampleA = "A"
    case sampleB = "B"

    var id: String { rawValue }
    var name: String {
        switch self {
        case .sampleA: return "샘플 A (14:53)"
        case .sampleB: return "샘플 B (14:57)"
        }
    }
    var uuids: [String] {
        switch self {
        case .sampleA:
            return ["4648", "4A4B", "D769", "0E9B", "6AE1", "CB94", "6048",
                    "1637", "013B", "B0AE", "1110", "1312", "1514"]
        case .sampleB:
            return ["08F9", "B249", "2CCE", "663F", "CD36", "7355", "600C",
                    "9F15", "1110", "1312", "1514", "1716", "1918"]
        }
    }
}

enum LampAction: String {
    case on, off

    var title: String { self == .on ? "ON" : "OFF" }
    var sourceKey: String { self == .on ? "lampOnSource" : "lampOffSource" }
    var customKey: String { self == .on ? "lampCustomOnFrames" : "lampCustomOffFrames" }
}

enum LampError: LocalizedError {
    case notConfigured(String)
    case noFrames
    case invalidUUID(String)
    case bluetoothUnavailable

    var errorDescription: String? {
        switch self {
        case .notConfigured(let name):
            return "\(name)에 연결할 샘플을 설정하지 않았습니다."
        case .noFrames:
            return "보낼 UUID 데이터가 없습니다."
        case .invalidUUID(let value):
            return "유효하지 않은 UUID: \(value)"
        case .bluetoothUnavailable:
            return "Bluetooth 권한 또는 상태를 확인해주세요."
        }
    }
}

@MainActor
final class LampController: NSObject, ObservableObject, CBPeripheralManagerDelegate {
    static let shared = LampController()

    @Published private(set) var statusText = "Bluetooth 준비 중..."
    @Published private(set) var isReady = false

    private var manager: CBPeripheralManager!
    private var queue: [[CBUUID]] = []
    private var timer: Timer?
    private var sendingLabel = ""

    private override init() {
        super.init()
        manager = CBPeripheralManager(delegate: self, queue: nil)
    }

    func showError(_ error: Error) {
        statusText = error.localizedDescription
    }

    func sendSample(_ sample: CapturedSample) throws {
        let frame = sample.uuids.map { CBUUID(string: $0) }
        try enqueue([frame], label: sample.name)
    }

    func send(_ action: LampAction) throws {
        let source = UserDefaults.standard.string(forKey: action.sourceKey) ?? "unassigned"
        let frames: [[CBUUID]]
        switch source {
        case "sampleA":
            frames = [CapturedSample.sampleA.uuids.map { CBUUID(string: $0) }]
        case "sampleB":
            frames = [CapturedSample.sampleB.uuids.map { CBUUID(string: $0) }]
        case "custom":
            let text = UserDefaults.standard.string(forKey: action.customKey) ?? ""
            frames = try Self.parseFrames(text)
        default:
            throw LampError.notConfigured(action.title)
        }
        try enqueue(frames, label: "전등 \(action.title)")
    }

    private func enqueue(_ frames: [[CBUUID]], label: String) throws {
        guard !frames.isEmpty else { throw LampError.noFrames }
        guard manager.state != .unsupported && manager.state != .unauthorized &&
              manager.state != .poweredOff else { throw LampError.bluetoothUnavailable }
        timer?.invalidate()
        manager.stopAdvertising()
        sendingLabel = label
        // The original app queues five repeats; real radio timing is OS-controlled.
        queue = Array(repeating: frames, count: 5).flatMap { $0 }
        statusText = "\(label): \(queue.count)개 광고 송신 요청 준비"
        if manager.state == .poweredOn { sendNext() }
    }

    private func sendNext() {
        guard manager.state == .poweredOn else { return }
        guard !queue.isEmpty else {
            manager.stopAdvertising()
            statusText = "\(sendingLabel): 광고 송신 요청 종료 (전등 수신 여부는 미확인)"
            return
        }
        let uuids = queue.removeFirst()
        manager.stopAdvertising()
        manager.startAdvertising([CBAdvertisementDataServiceUUIDsKey: uuids])
        // Deliberately slightly slower than the original 150ms to tolerate iOS scheduling.
        timer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: false) { [weak self] _ in
            Task { @MainActor in self?.sendNext() }
        }
    }

    private static func parseFrames(_ input: String) throws -> [[CBUUID]] {
        var result: [[CBUUID]] = []
        for line in input.components(separatedBy: .newlines) {
            let noComment = String(line.split(separator: "#", maxSplits: 1,
                                             omittingEmptySubsequences: false).first ?? "")
            let items = noComment.replacingOccurrences(of: ",", with: " ")
                .replacingOccurrences(of: ";", with: " ")
                .split(whereSeparator: { $0.isWhitespace })
            var uuids: [CBUUID] = []
            for item in items {
                var str = String(item)
                if str.lowercased().hasPrefix("0x") { str = String(str.dropFirst(2)) }
                let is16 = str.count == 4 && str.unicodeScalars.allSatisfy {
                    CharacterSet(charactersIn: "0123456789abcdefABCDEF").contains($0)
                }
                guard is16 || UUID(uuidString: str) != nil else {
                    throw LampError.invalidUUID(str)
                }
                uuids.append(CBUUID(string: str))
            }
            if !uuids.isEmpty { result.append(uuids) }
        }
        return result
    }

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        isReady = (peripheral.state == .poweredOn)
        switch peripheral.state {
        case .poweredOn:
            statusText = "Bluetooth 준비 완료"
            if !queue.isEmpty { sendNext() }
        case .poweredOff: statusText = "Bluetooth 꺼짐"
        case .unauthorized: statusText = "Bluetooth 접근 권한 없음"
        case .unsupported: statusText = "BLE Peripheral 모드 미지원"
        case .resetting: statusText = "Bluetooth 초기화 중"
        case .unknown: statusText = "Bluetooth 준비 중"
        @unknown default: statusText = "Bluetooth 상태 알 수 없음"
        }
    }

    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        if let error {
            timer?.invalidate()
            queue.removeAll()
            statusText = "광고 송신 오류: \(error.localizedDescription)"
        }
    }
}
