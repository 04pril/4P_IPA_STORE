import SwiftUI

struct LampView: View {
    @ObservedObject private var lamp = LampController.shared
    @AppStorage("lampOnSource") private var onSource = "unassigned"
    @AppStorage("lampOffSource") private var offSource = "unassigned"
    @AppStorage("lampCustomOnFrames") private var customOn = ""
    @AppStorage("lampCustomOffFrames") private var customOff = ""
    @State private var showAdvanced = false

    private struct SourceOption: Identifiable {
        let title: String
        let value: String
        var id: String { value }
    }

    private let sourceOptions = [
        SourceOption(title: "미설정", value: "unassigned"),
        SourceOption(title: "샘플 A (14:53)", value: "sampleA"),
        SourceOption(title: "샘플 B (14:57)", value: "sampleB"),
        SourceOption(title: "직접 입력", value: "custom")
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(spacing: 8) {
                        Image(systemName: "lightbulb.2.fill")
                            .font(.system(size: 58))
                            .foregroundStyle(.orange)
                        Text("智美灯控 전등 제어")
                            .font(.title2.bold())
                        Text("IPA 기반 BLE 광고 송신 테스트")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)

                    VStack(alignment: .leading, spacing: 8) {
                        Label("원본 앱에서 캡처한 2개 샘플", systemImage: "antenna.radiowaves.left.and.right")
                            .font(.headline)
                        Text("아직 어느 샘플이 ON인지 OFF인지 확인되지 않았습니다. 전등 없이 송신 테스트만 가능합니다.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        HStack(spacing: 12) {
                            Button("샘플 A 송신") { triggerSample(.sampleA) }
                                .buttonStyle(.borderedProminent)
                            Button("샘플 B 송신") { triggerSample(.sampleB) }
                                .buttonStyle(.borderedProminent)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))

                    VStack(alignment: .leading, spacing: 12) {
                        Text("ON/OFF 샘플 배정")
                            .font(.headline)
                        Picker("켜기 명령", selection: $onSource) {
                            ForEach(sourceOptions) { option in
                                Text(option.title).tag(option.value)
                            }
                        }
                        Picker("끄기 명령", selection: $offSource) {
                            ForEach(sourceOptions) { option in
                                Text(option.title).tag(option.value)
                            }
                        }
                        if onSource == offSource && onSource != "unassigned" {
                            Text("주의: ON과 OFF에 같은 데이터를 배정했습니다.")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                        HStack(spacing: 12) {
                            Button { trigger(.on) } label: {
                                Label("ON", systemImage: "lightbulb.fill")
                                    .frame(maxWidth: .infinity, minHeight: 54)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.green)
                            .disabled(onSource == "unassigned")

                            Button { trigger(.off) } label: {
                                Label("OFF", systemImage: "lightbulb.slash.fill")
                                    .frame(maxWidth: .infinity, minHeight: 54)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.gray)
                            .disabled(offSource == "unassigned")
                        }
                    }
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))

                    Text(lamp.statusText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)

                    DisclosureGroup("고급: 다른 패킷 직접 입력", isExpanded: $showAdvanced) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("광고 한 건당 한 줄씩 16비트 UUID를 공백으로 구분해 입력하세요.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("ON 사용자 정의")
                            TextEditor(text: $customOn)
                                .font(.system(.caption, design: .monospaced))
                                .frame(height: 95)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(.gray.opacity(0.3)))
                            Text("OFF 사용자 정의")
                            TextEditor(text: $customOff)
                                .font(.system(.caption, design: .monospaced))
                                .frame(height: 95)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(.gray.opacity(0.3)))
                        }
                    }
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))

                    Text("단축어: Turn Light On / Turn Light Off. 딥링크: zhimei-switch://on 또는 zhimei-switch://off. 명령이 실제 전등에 작동하는지 검증된 앱은 아닙니다.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .navigationTitle("Light Switch")
        }
    }

    private func trigger(_ action: LampAction) {
        do { try lamp.send(action) } catch { lamp.showError(error) }
    }

    private func triggerSample(_ sample: CapturedSample) {
        do { try lamp.sendSample(sample) } catch { lamp.showError(error) }
    }
}
